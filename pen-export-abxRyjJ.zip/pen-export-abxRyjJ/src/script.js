function redirectToCodePen() {
  
    window.location.href = "https://codepen.io/Artembeef-the-selector/full/vYwXJbv";
}